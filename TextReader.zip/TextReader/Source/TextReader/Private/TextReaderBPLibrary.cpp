// Copyright Epic Games, Inc. All Rights Reserved.

#include "TextReaderBPLibrary.h"
#include "TextReader.h"

FText UTextReaderBPLibrary::LoadFileContentAsText(const FText& FilePath)
{
	
	FString FileContent;
	FString FilePathString = FilePath.ToString();

	if (FFileHelper::LoadFileToString(FileContent, *FilePathString))
	{
		return FText::FromString(FileContent);

	}
	return FText::GetEmpty();

}
