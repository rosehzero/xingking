// Copyright Epic Games, Inc. All Rights Reserved.

#pragma once

#include "Kismet/BlueprintFunctionLibrary.h"
#include "TextReaderBPLibrary.generated.h"



UCLASS()
class UTextReaderBPLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

	UFUNCTION(BlueprintCallable)
	static FText LoadFileContentAsText(const FText& FilePath);

};
